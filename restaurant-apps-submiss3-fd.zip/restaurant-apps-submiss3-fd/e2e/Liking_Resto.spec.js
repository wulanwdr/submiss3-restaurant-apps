const assert = require('assert');

Feature('Liking Resto');

Before(({ I }) => {
  I.amOnPage('/#/favorit');
  I.wait(3);
});

Scenario('showing empty liked restaurant', ({ I }) => {
  I.seeElement('.content');
  I.seeElement('.restaurant-item__not__found');
});

Scenario('liking one restaurant', async ({ I }) => {
  I.amOnPage('/');

  I.wait(2);

  I.waitForElement('.card a');

  const firstRestaurant = locate('.card a').first();
  const firstRestaurantName = await I.grabTextFrom(firstRestaurant);

  I.click(firstRestaurant);

  I.wait(2);

  I.waitForElement('#likeButton');
  I.click('#likeButton');
  I.wait(2);

  I.amOnPage('/#/favorit');

  I.wait(2);

  I.waitForElement('.card');

  const likedRestaurantName = await I.grabTextFrom('.card a');

  assert.strictEqual(likedRestaurantName, firstRestaurantName);
});

Scenario('unliking one restaurant', async ({ I }) => {
  I.amOnPage('/');

  I.wait(2);

  I.waitForElement('.card a');

  const firstRestaurant = locate('.card a').first();
  const firstRestaurantName = await I.grabTextFrom(firstRestaurant);

  I.click(firstRestaurant);

  I.wait(2);

  I.waitForElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/favorit');

  I.wait(2);

  I.waitForElement('.card');

  const likedRestaurantName = await I.grabTextFrom('.card a');

  assert.strictEqual(likedRestaurantName, firstRestaurantName);

  I.click('.card a');

  I.wait(2);

  I.waitForElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/favorit');

  I.wait(2);

  I.dontSeeElement('.card');
});