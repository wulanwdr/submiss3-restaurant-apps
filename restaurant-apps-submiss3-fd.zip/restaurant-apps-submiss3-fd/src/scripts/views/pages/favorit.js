import FavoriteResto from '../../data/favorit-resto';
import { createRestoItemTemplate } from '../templates/template-resto';

const Favorit = {
  async render() {
    return `
        <a href="#content" class="skip-link">Menuju ke konten</a>    
        <section id="content" class="content">
        <div class="restaurant-item__not__found"></div>
            <h2>Your Favorite Restaurant List</h2>
            <div id="list" class="listresto">
            </div>
        </section>
      `;
  },

  async afterRender() {
    // Fungsi ini akan dipanggil setelah render()
    const restaurants = await FavoriteResto.getAllRestaurants();
    const restaurantsContainer = document.querySelector('#list');
    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestoItemTemplate(restaurant);
    });
  },
};
export default Favorit;
