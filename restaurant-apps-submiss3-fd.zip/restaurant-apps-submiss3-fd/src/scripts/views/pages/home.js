import RestoDbSource from '../../data/resto-source';
import { createRestoItemTemplate } from '../templates/template-resto';

const Home = {
  async render() {
    return `
        <div class="hero">
          <div>
            <picture>
              <source
              media="(max-width: 600px)"
              type="image/jpg"
              srcset="/images/heros/hero-image_2-small.jpg"
              />
              <img src="/images/heros/hero-image_2-large.jpg" alt="image-hero-restaurant" />
            </picture>
          </div>
            <div class="hero__inner">
                <h2 class="hero__title">Taste Sensations</h2>
                <p class="hero__tagline">"Recommendations for Food Lovers"</p>
            </div>
        </div>

        <section class="content">
            <h2>Exploring Authentic Restaurant</h2>
            <div id="list" class="listresto">
            </div>
        </section>
      `;
  },

  async afterRender() {
    // Fungsi ini akan dipanggil setelah render()
    const restaurants = await RestoDbSource.restaurants();
    const restaurantsContainer = document.querySelector('#list');
    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestoItemTemplate(restaurant);
    });
  },
};

export default Home;
